    let btn = document.querySelector('.showMovies');
    let sortAZ = document.querySelector('.sortAz');
    let sortZA = document.querySelector('.sortZa');
    let hide = document.querySelector('.hideMovies')

    let arr = [
      'Министерство неджентльменских дел',
      'Артур, ты король',
      'Онегин',
      'Дюна: Часть вторая',
      'Территория зла',
      'Из глубины',
    ];

    function showMovies() {
      const movies = document.querySelector('#movies');
      movies.innerHTML = ''
        
      for (let i = 0; i < arr.length; i++) {
        
        const movie = document.createElement('p');
        movie.textContent = arr[i];
        movies.appendChild(movie);
        
      }
      
    }
    function hideMovies() {
        const movies = document.querySelector('#movies');
        movies.innerHTML = ''; 
      }
    
    function sortAz() {
      arr.sort();
      showMovies(); 
    }

    function sortZa() {
      arr.sort().reverse(); 
      showMovies(); 
    }

      btn.addEventListener('click', showMovies);
      sortAZ.addEventListener('click', sortAz);
      sortZA.addEventListener('click', sortZa);
      hide.addEventListener('click', hideMovies);

      



// 1) При нажати на кнопку показать , необходимо чтобы появился список фильмов из массива "arr"
// 2) Когда нажимаете на кнопку "а-я" произошла сортировка фильмов по алфавиту с начала
// 3) Когда нажимаете на кнопку "я-а" произошла сортировка фильмов по алфавиту с конца
// 4) Сделайте максимально красивые стили

